# My Inventory - Multi-Screen Flutter App

A beautiful multi-screen Flutter application to manage and track your personal items across different categories **with image support**.

## Categories Supported
- Books
- Jewellery
- Keys
- Clothes
- Chocolates
- Accessories
- Food
- Flowers
- Laptop

## Features
- **Home Screen**: Beautiful grid of all categories with icons and colors
- **Category Screen**: View all items in a selected category with **thumbnails**
- **Add / Edit Item Screen**: Form to add new items + **pick photo from Gallery or Camera**
- **Item Detail Screen**: Full details with large **item image**
- **Local Persistence**: Data + images saved on device (survives app restarts)
- Pull to Refresh, Delete, Edit support
- Modern Material 3 UI

## Screens
1. **HomeScreen** → Category selection grid
2. **CategoryScreen** → List of items (with image thumbnails) + FAB to add
3. **AddItemScreen** → Form + image picker (Gallery / Camera)
4. **ItemDetailScreen** → Large image + full details + edit

## How to Run

### Prerequisites
- Flutter SDK (>=3.0.0)
- Android Studio / VS Code with Flutter extension
- An emulator or physical device

### Steps
1. Extract this ZIP file
2. Open terminal in the project folder
3. Run:
   ```bash
   flutter pub get
   flutter run
   ```

### Android Permissions
You may need these in `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
```

### iOS
Add to `ios/Runner/Info.plist`:
```xml
<key>NSCameraUsageDescription</key>
<string>We need camera access to take photos of your items</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>We need photo library access to select item images</string>
```

### Project Structure
```
lib/
├── main.dart
├── models/
│   └── item.dart          (includes imagePath)
├── services/
│   └── item_service.dart
└── screens/
    ├── home_screen.dart
    ├── category_screen.dart
    ├── add_item_screen.dart
    └── item_detail_screen.dart
```

## Dependencies
- shared_preferences – local data storage
- uuid – unique item IDs
- image_picker – pick images from gallery or camera
- path_provider + path – save images permanently in app documents

Enjoy managing your inventory with photos!
