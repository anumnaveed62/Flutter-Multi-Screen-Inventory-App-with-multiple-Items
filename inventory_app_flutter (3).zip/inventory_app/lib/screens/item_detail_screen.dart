import 'dart:io';
import 'package:flutter/material.dart';
import '../models/item.dart';
import 'add_item_screen.dart';

class ItemDetailScreen extends StatelessWidget {
  final Item item;
  final Color categoryColor;
  final IconData categoryIcon;
  final VoidCallback onUpdated;

  const ItemDetailScreen({
    super.key,
    required this.item,
    required this.categoryColor,
    required this.categoryIcon,
    required this.onUpdated,
  });

  @override
  Widget build(BuildContext context) {
    final hasImage = item.imagePath != null && File(item.imagePath!).existsSync();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Item Details'),
        backgroundColor: categoryColor.withOpacity(0.15),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AddItemScreen(
                    categoryName: item.category,
                    categoryColor: categoryColor,
                    existingItem: item,
                  ),
                ),
              );
              if (result == true) {
                onUpdated();
                if (context.mounted) Navigator.pop(context);
              }
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image or placeholder
            if (hasImage)
              SizedBox(
                width: double.infinity,
                height: 280,
                child: Image.file(
                  File(item.imagePath!),
                  fit: BoxFit.cover,
                ),
              )
            else
              Container(
                width: double.infinity,
                height: 200,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      categoryColor.withOpacity(0.3),
                      categoryColor.withOpacity(0.1),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Center(
                  child: Icon(
                    categoryIcon,
                    size: 80,
                    color: categoryColor.withOpacity(0.6),
                  ),
                ),
              ),

            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Name + Category
                  Text(
                    item.name,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Chip(
                    avatar: Icon(categoryIcon, size: 18, color: categoryColor),
                    label: Text(item.category),
                    backgroundColor: categoryColor.withOpacity(0.15),
                    labelStyle: TextStyle(
                      color: categoryColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Details
                  _DetailRow(
                    icon: Icons.numbers,
                    label: 'Quantity',
                    value: item.quantity.toString(),
                    color: categoryColor,
                  ),
                  const Divider(height: 32),
                  _DetailRow(
                    icon: Icons.notes,
                    label: 'Description',
                    value: item.description.isEmpty ? 'No description' : item.description,
                    color: categoryColor,
                  ),
                  const Divider(height: 32),
                  _DetailRow(
                    icon: Icons.calendar_today,
                    label: 'Added On',
                    value: _formatDate(item.createdAt),
                    color: categoryColor,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}  ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _DetailRow({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: color, size: 22),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
