import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/item.dart';

class ItemService {
  static const String _key = 'inventory_items';

  Future<List<Item>> getAllItems() async {
    final prefs = await SharedPreferences.getInstance();
    final String? data = prefs.getString(_key);
    if (data == null) return [];
    final List<dynamic> jsonList = jsonDecode(data);
    return jsonList.map((e) => Item.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<List<Item>> getItemsByCategory(String category) async {
    final items = await getAllItems();
    return items.where((item) => item.category == category).toList();
  }

  Future<void> addItem(Item item) async {
    final items = await getAllItems();
    items.add(item);
    await _save(items);
  }

  Future<void> updateItem(Item item) async {
    final items = await getAllItems();
    final index = items.indexWhere((i) => i.id == item.id);
    if (index != -1) {
      items[index] = item;
      await _save(items);
    }
  }

  Future<void> deleteItem(String id) async {
    final items = await getAllItems();
    items.removeWhere((i) => i.id == id);
    await _save(items);
  }

  Future<void> _save(List<Item> items) async {
    final prefs = await SharedPreferences.getInstance();
    final String data = jsonEncode(items.map((e) => e.toJson()).toList());
    await prefs.setString(_key, data);
  }
}
